from __future__ import annotations

from typing import NewType

from chia.util.ints import uint64

Mojos = NewType("Mojos", uint64)
