from __future__ import annotations

from chia.cmds.chia import main

main()
